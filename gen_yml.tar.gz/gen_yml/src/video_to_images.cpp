/*@author Badr Dami*/

#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/core/core.hpp"



#include <iostream>
#include <stdio.h>

#include "video_to_images.hpp"

using namespace cv ;
using namespace std ;

int video_to_images(){
    
    VideoCapture capture(0);
    Mat frame;
    Mat face_resized;
    
    if(!capture.isOpened())
        return -1 ;
    
    Mat testSample = imread("/Users/badrdami/ProjetSpe/reconnaissance/orl_faces/s1/1.pgm", 0);
    if(! testSample.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
    }
    
    int img_width = testSample.cols;
    int img_height = testSample.rows;
    /*recise images to get only the face */
    string classifier = "/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml";
    
    CascadeClassifier face_cascade;
    string window = "Capture - face detection";
    
    if (!face_cascade.load(classifier)){
        cout << " Error loading file haarcascade_frintalface_default.xlm in fisherFaceTrainer" << endl;
    }
    while(true){
        capture >> frame;
        if( !frame.empty() ){
            char c = (char) waitKey(10);
            if(c == 'q')
                break;
            else{
                int filenumber ;
                String filename;
                filename = "";
                
                //clone from original frame
                Mat original = frame.clone();
                Mat graySacleFrame ;
                vector<Rect> faces;
                //convert image to gray scale and equalize
                cvtColor(original, graySacleFrame, COLOR_BGR2GRAY);
                equalizeHist(graySacleFrame, graySacleFrame);
                
                //detect face in gray image
                face_cascade.detectMultiScale(graySacleFrame, faces, 1.1, 3, 0, cv::Size(90, 90));
                Mat face = graySacleFrame(faces[0]);
                
                //Mat face_resized;
                cv::resize(face, face_resized, Size(img_width, img_height), 1.0, 1.0, INTER_CUBIC);
                
                std::stringstream ssfn;
                ssfn << filenumber << "a.pgm";
                filename = "/Users/badrdami/ProjetSpe/reconnaissance/orl_faces/badr/badr2_"+ssfn.str();
                cout << filename << endl ;
                filenumber++;
                
                string window_name2 = "personne_face" ;
                imshow( window_name2, face_resized );
                if((char)waitKey(10)=='f')
                    imwrite(filename, face_resized);
            }
        }
        else {
            cout <<"pas d'image"<<endl;
            break;
        }
        
    }
    return 1 ;
    
    
}