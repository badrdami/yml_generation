//
//  faceRec.hpp
//  reconnaissance
//
//  Created by badr dami on 09/06/2016.
//  Copyright © 2016 badr dami. All rights reserved.
//

#ifndef faceRec_hpp
#define faceRec_hpp

#include <stdio.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <thread>

//include opencv core
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/opencv.hpp"
#include "opencv2/contrib/contrib.hpp"
#include "opencv2/imgproc/imgproc.hpp"

//file handling
#include <fstream>
#include <sstream>

class FaceRec {
    
public:
    
    //bool first_speech = true;
    static cv::Mat MatNorm(cv::InputArray _src);
    static void dbread(const cv::string& filename, cv::vector<cv::Mat>& images, cv::vector<int>& labels, char separator = ';');
    void eigenFaceTrainer();
    void fisherFaceTrainer();
    void LBPHFaceTrainer();
    int  FaceRecognition();
    
protected:
    
};

#endif







