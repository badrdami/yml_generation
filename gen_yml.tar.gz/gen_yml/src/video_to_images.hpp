/*@author Badr Dami*/


//  video_to_images.hpp
//  Opencv2
//
//  Created by badr dami on 22/05/2016.
//  Copyright © 2016 badr dami. All rights reserved.
//

#ifndef video_to_images_hpp
#define video_to_images_hpp

#include <stdio.h>

#endif /* video_to_images_hpp */

int video_to_images();