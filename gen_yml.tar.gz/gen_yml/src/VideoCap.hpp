/*@author Badr Dami*/

#include <iostream>
#include <string>

//video capturing methods

	int videoCapturing();
	int videoCapOriginal();

	/*detect the faces display the frames and number of face*/
	int FaceDetector(std::string&);

