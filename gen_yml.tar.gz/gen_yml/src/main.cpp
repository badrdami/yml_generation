/*@author Badr Dami*/

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

#include "video_to_images.hpp"
#include "faceRec.hpp"
#include "VideoCap.hpp"


using namespace cv;
using namespace std;


int main()
{
    FaceRec face;
    //face.fisherFaceTrainer();
    
    
    /*
    char buff[512];
    FILE* f = popen("sh /Users/badrdami/ProjetSpe/reconnaissance/reco_vocale/parse_scripte.sh", "r") ;
    fgets(buff, sizeof(buff), f);
    cout << "voilà la reponse: " << buff;
    pclose(f); */

    
    face.LBPHFaceTrainer();
    //face.eigenFaceTrainer();
    
    //FaceRec fase;
    //int value = fase.FaceRecognition();
    
    //int x = videoCapturing() ;
    //int x = get_image_car();
    
    //int x = video_to_images();
    
    //int x = smoothingImage();
    //int x = edgeDetectionsCanny();
    
    //system("pause");
    return 0; 
}
