//
//  faceRec.cpp
//  reconnaissance
//
//  Created by badr dami on 09/06/2016.
//  Copyright © 2016 badr dami. All rights reserved.
//

#include "faceRec.hpp"

using namespace cv ;
using namespace std ;

 Mat FaceRec::MatNorm(InputArray _src) {
    Mat src = _src.getMat();
    // Create and return normalized image:
    Mat dst;
    switch (src.channels()) {
        case 1:
            normalize(_src, dst, 0, 255, NORM_MINMAX, CV_8UC1);
            break;
        case 3:
            normalize(_src, dst, 0, 255, NORM_MINMAX, CV_8UC3);
            break;
        default:
            src.copyTo(dst);
            break;
    }
    return dst;
}

 void FaceRec::dbread(const string& filename, vector<Mat>& images, vector<int>& labels, char separator){
    ifstream file(filename.c_str(), ifstream::in);
    
    if (!file){
        string error = "no valid input file";
        CV_Error(CV_StsBadArg, error);
    }
    
    string line, path, label;
    while (getline(file, line))
    {
        stringstream liness(line);
        getline(liness, path, separator);
        getline(liness, label);
        if (!path.empty() && !label.empty()){
            Mat m = imread(path, 1);
            //Check for invalid input
            if(! m.data )
            {
                cout <<  "Could not open or find the image" << std::endl ;
                cout << "path: " << path << std::endl ;
            }
            //equalizeHist(m, m);
            Mat m2;
            cvtColor(m,m2,COLOR_BGR2GRAY);
            images.push_back(m2);
            labels.push_back(atoi(label.c_str()));
        }
    }
}

void FaceRec::eigenFaceTrainer(){
    vector<Mat> images;
    vector<int> labels;
    
    try{
        string filename = "../photo/fichier/File.txt";
        dbread(filename, images, labels, ';');
        
        cout << "size of the images is " << images.size() << endl;
        cout << "size of the labes is " << labels.size() << endl;
        cout << "Training begins...." << endl;
    }
    catch (Exception& e){
        cerr << " Error opening the file " << e.msg << endl;
        exit(1);
    }
    
    //create algorithm eigenface recognizer
    Ptr<FaceRecognizer>  model = createEigenFaceRecognizer();
    //train data
    model->train(images, labels);
    
    model->save("../photo/fichier/eigenface.yml");
    
    cout << "Training finished...." << endl;
}

void FaceRec::fisherFaceTrainer(){
    /*in this two vector we put the images and labes for training*/
    vector<Mat> images;
    vector<int> labels;
    
    
    try{
        string filename = "../photo/fichier/File.txt";
        dbread(filename, images, labels, ';');
        
        cout << "size of the images is " << images.size() << endl;
        cout << "size of the labes is " << labels.size() << endl;
        cout << "Training begins...." << endl;
    }
    catch (Exception& e){
        cerr << " Error opening the file " << e.msg << endl;
        exit(1);
    }
    Ptr<FaceRecognizer> model = createFisherFaceRecognizer();
    
    model->train(images, labels);
    int height = images[0].rows;
    
    model->save("../photo/fichier/fisherface.yml");
    
    cout << "Training finished...." << endl;
}

void FaceRec::LBPHFaceTrainer(){
    
    vector<Mat> images;
    vector<int> labels;
    
    try{
        string filename = "../photo/fichier/File.txt";
        dbread(filename, images, labels, ';');
        
        cout << "size of the images is " << images.size() << endl;
        cout << "size of the labes is " << labels.size() << endl;
        cout << "Training begins...." << endl;
    }
    catch (Exception& e){
        cerr << " Error opening the file " << e.msg << endl;
        exit(1);
    }
    
    //lbph face recognier model
    Ptr<FaceRecognizer> model = createLBPHFaceRecognizer();
    
    //training images with relevant labels
    model->train(images, labels);
    
    //save the data in yaml file
    model->save("../photo/fichier/LBPHface_final_test.yml");
    
    cout << "training finished...." << endl;
}


//lbpcascades works in lbphrecognier as fast as haarcascades
int  FaceRec::FaceRecognition(){
    
    cout << "start recognizing..." << endl;
    
    //load pre-trained data sets
    /*
     Ptr<cv::face::FaceRecognizer>  model = cv::face::createFisherFaceRecognizer();
     model->load("/Users/badrdami/ProjetSpe/Opencv2/photo/fichier/fisherface.yml");*/
    
    
     Ptr<FaceRecognizer> model = createLBPHFaceRecognizer();
     model->load("../photo/fichier/LBPHface_final.yml");
    
    /*
    Ptr<FaceRecognizer> model = createEigenFaceRecognizer();
    model->load("/Users/badrdami/ProjetSpe/reconnaissance/photo/fichier/eigenface.yml");*/
    
    
    
    
    Mat testSample = imread("../orl_faces/badr/badr_81&.pgm", 0);
    
    int img_width = testSample.cols;
    int img_height = testSample.rows;
    
    
    //lbpcascades/lbpcascade_frontalface.xml
    string classifier = "/usr/local/share/Opencv/haarcascades/haarcascade_frontalface_alt2.xml";
    
    CascadeClassifier face_cascade;
    string window = "Capture - face detection";
    
    if (!face_cascade.load(classifier)){
        cout << " Error loading file" << endl;
        return -1;
    }
    
    VideoCapture cap(0);
    //VideoCapture cap("C:/Users/lsf-admin/Pictures/Camera Roll/video000.mp4");
    
    if (!cap.isOpened())
    {
        cout << "exit" << endl;
        return -1;
    }
    
    //double fps = cap.get(CV_CAP_PROP_FPS);
    //cout << " Frames per seconds " << fps << endl;
    namedWindow(window, 1);
    long count = 0;
    
    
    
    while (true)
    {
        vector<Rect> faces;
        Mat frame;
        Mat graySacleFrame;
        Mat original ;
        
        cap >> frame;
        //cap.read(frame);
        count = count + 1;//count frames;
        
        
        pid_t PID = 0;
        int returnStatus ;
        
        if (!frame.empty()){
            
            //clone from original frame
            original = frame.clone();
            
            //convert image to gray scale and equalize
            cvtColor(original, graySacleFrame, COLOR_BGR2GRAY);
            equalizeHist(graySacleFrame, graySacleFrame);
            
            //detect face in gray image
            face_cascade.detectMultiScale(graySacleFrame, faces, 1.1, 3, 0, cv::Size(90, 90));
            
            //number of faces detected
            //cout << faces.size() << " faces detected" << endl;
            string frameset = to_string(count);
            string faceset = to_string(faces.size());
            
            int width = 0, height = 0;
            
            //region of interest
            //cv::Rect roi;
            
            //person name
            string Pname ;
            
            int label = -1; double confidence = 0;
            for (int i = 0; i < faces.size(); i++)
            {
                //region of interest
                Rect face_i = faces[i];
                
                //crop the roi from grya image
                Mat face = graySacleFrame(face_i);
                
                //resizing the cropped image to suit to database image sizes
                Mat face_resized;
                resize(face, face_resized, Size(img_width, img_height), 1.0, 1.0, INTER_CUBIC);
                
                string window_name = "personne" ;
                imshow( window_name, face_resized );
                
                //recognizing what faces detected
                
                model->predict(face_resized,label,confidence);
                
                
                //cout << " confidencde " << confidence << endl;
                
                //drawing green rectagle in recognize face
                rectangle(original, face_i, Scalar(0, 255, 0), 1);       // CV_RGB ---> Scalar
                string text = "Detected";
                //cout << "labelllllllllllllllllll" << label << endl;
                //cout << "confidence" << confidence << endl;
                Pname = "-----";
                switch (label)
                {
                    case 40: Pname = "BADR";
                        break;
                    case 41: Pname = "AHMED";
                        break;
                    default: Pname = "unknown";
                        break;
                }
                
                int pos_x = std::max(face_i.tl().x - 10, 0);
                int pos_y = std::max(face_i.tl().y - 10, 0);
                
                //name the person who is in the image
                putText(original, Pname, Point(pos_x, pos_y), FONT_HERSHEY_COMPLEX_SMALL, 1.0, Scalar(0, 255, 0), 1.0);  // CV_RGB ---> Scalar
                //cv::imwrite("E:/FDB/"+frameset+".jpg", cropImg);
                
            }
            /*
            if(label==40 /*&& first_speech/){
                
                first_speech = false ;
                //std::thread first (rec_speech);
                
                PID = fork();
                if(PID==0){
                    rec_speech();
                    goto stop ;
                }
                
            }
            */
            
            putText(original, "Frames: " + frameset, Point(30, 60), FONT_HERSHEY_COMPLEX_SMALL, 1.0, Scalar(0, 255, 0), 1.0);
            putText(original, "Person: " + Pname, Point(30, 90), FONT_HERSHEY_COMPLEX_SMALL, 1.0, Scalar(0, 255, 0), 1.0);
            //display to the winodw
            imshow(window, original);
            
            //cout << "model infor " << model->getDouble("threshold") << endl;
            
        }
        
        if (waitKey(30) >= 0) break;
    }
    return 1;
}
